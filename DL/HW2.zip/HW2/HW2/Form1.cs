﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions; // ใช้สำหรับตรวจสอบรูปแบบอีเมลตามหลักสากล
using System.Windows.Forms;

namespace HW2
{
    public partial class Form1 : Form
    {
        // กำหนดตำแหน่งสำหรับบันทึกไฟล์ฐานข้อมูลข้อความ
        private string autoSaveFilePath = Path.Combine(Application.StartupPath, "database_contacts.txt");

        public Form1()
        {
            InitializeComponent();

            // 1. ผูกปุ่มคำสั่งหลักให้ทำงาน สัมพันธ์กับฟังก์ชันเซฟและล้างข้อมูล
            button1.Click -= button1_Click;
            button1.Click += button1_Click;
            button2.Click -= button2_Click;
            button2.Click += button2_Click;

            // =========================================================
            // 🛡️ 2. ระบบดักจับการพิมพ์ผิด (Real-time Validation)
            // =========================================================

            // กลุ่ม A: ช่องที่บังคับกรอกเฉพาะ "ตัวอักษรและช่องว่าง" เท่านั้น
            textBox1.TextChanged += OnlyLetters_TextChanged; // ช่อง Name
            textBox2.TextChanged += OnlyLetters_TextChanged; // ช่อง Last Name

            // กลุ่ม B: ช่องที่บังคับกรอกเฉพาะ "ตัวเลข" เท่านั้น
            textBox5.TextChanged += OnlyNumbers_TextChanged;  // ✅ Home Phone
            textBox6.TextChanged += OnlyNumbers_TextChanged;  // ✅ Mobile Phone
            textBox17.TextChanged += OnlyNumbers_TextChanged; // ✅ Emergency Phone
            textBox15.TextChanged += OnlyNumbers_TextChanged; // ✅ Zip Code

            // =========================================================
            // 📧 3. ระบบตรวจสอบอีเมลตามหลักสากล (เตือนเมื่อพิมพ์เสร็จแล้วย้ายช่อง)
            // =========================================================
            textBox10.Leave += ValidateEmail_Leave; // ✅ Personal Email
            textBox11.Leave += ValidateEmail_Leave; // ✅ Work Email
        }

        // 🚦 ฟังก์ชันตรวจสอบรูปแบบอีเมลเมื่อผู้ใช้กรอกเสร็จแล้วกดเปลี่ยนช่อง
        private void ValidateEmail_Leave(object sender, EventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (txt == null || string.IsNullOrWhiteSpace(txt.Text)) return; // ถ้าปล่อยว่างไว้ ไม่ต้องตรวจสอบ

            // แพทเทิร์น Regex ตรวจสอบโครงสร้างอีเมลสากล (ต้องมี @ และมีจุด .com/.co.th)
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

            if (!Regex.IsMatch(txt.Text.Trim(), emailPattern))
            {
                MessageBox.Show("รูปแบบอีเมลไม่ถูกต้องตามหลักสากลครับ!\nกรุณาตรวจสอบอีกครั้ง (ตัวอย่าง: name@domain.com)",
                                "รูปแบบอีเมลไม่ถูกต้อง", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt.Focus(); // ดึงเคอร์เซอร์กลับไปให้แก้ไขให้ถูกต้อง
            }
        }

        // ฟังก์ชันดักจับ: อนุญาตเฉพาะตัวอักษร
        private void OnlyLetters_TextChanged(object sender, EventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (txt == null) return;

            if (txt.Text.Any(c => char.IsDigit(c) || char.IsPunctuation(c) || char.IsSymbol(c)))
            {
                MessageBox.Show("ช่องนี้กรอกได้เฉพาะ 'ตัวอักษร' เท่านั้นครับ ห้ามใส่ตัวเลขหรือสัญลักษณ์", "แจ้งเตือนการพิมพ์", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt.Text = new string(txt.Text.Where(c => char.IsLetter(c) || char.IsWhiteSpace(c)).ToArray());
                txt.SelectionStart = txt.Text.Length;
            }
        }

        // ฟังก์ชันดักจับ: อนุญาตเฉพาะตัวเลข
        private void OnlyNumbers_TextChanged(object sender, EventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (txt == null) return;

            if (txt.Text.Any(c => !char.IsDigit(c)))
            {
                MessageBox.Show("ช่องนี้กรอกได้เฉพาะ 'ตัวเลข' เท่านั้นครับ!", "แจ้งเตือนการพิมพ์", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txt.Text = new string(txt.Text.Where(char.IsDigit).ToArray());
                txt.SelectionStart = txt.Text.Length;
            }
        }

        // =========================================================
        // 🟢 ปุ่ม "Save" บันทึกประวัติลงไฟล์ Text + เปิดไฟล์อัตโนมัติ
        // =========================================================
        private void button1_Click(object sender, EventArgs e)
        {
            // ตรวจสอบเงื่อนไขบังคับพื้นฐาน (ชื่อ นามสกุล)
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("กรุณากรอก 'ชื่อ' และ 'นามสกุล' ให้เรียบร้อยก่อนกดบันทึกครับ", "ข้อมูลไม่ครบถ้วน", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                return;
            }

            // ตรวจสอบความถูกต้องของอีเมลทั้งสองช่องอีกรอบก่อนยอมให้บันทึกไฟล์
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            if (!string.IsNullOrWhiteSpace(textBox10.Text) && !Regex.IsMatch(textBox10.Text.Trim(), emailPattern))
            {
                MessageBox.Show("กรุณาแก้ไข 'Personal Email' ให้ถูกต้องตามหลักการก่อนบันทึกครับ", "ข้อมูลไม่ถูกต้อง", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox10.Focus();
                return;
            }
            if (!string.IsNullOrWhiteSpace(textBox11.Text) && !Regex.IsMatch(textBox11.Text.Trim(), emailPattern))
            {
                MessageBox.Show("กรุณาแก้ไข 'Work Email' ให้ถูกต้องตามหลักการก่อนบันทึกครับ", "ข้อมูลไม่ถูกต้อง", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox11.Focus();
                return;
            }

            try
            {
                // บันทึกข้อมูลลงไฟล์ Text
                using (StreamWriter writer = new StreamWriter(autoSaveFilePath, true))
                {
                    writer.WriteLine("==================================================");
                    writer.WriteLine($" Date Saved: {DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")}");
                    writer.WriteLine("==================================================");
                    writer.WriteLine($"   Name           : {textBox1.Text.Trim()} {textBox2.Text.Trim()}");
                    writer.WriteLine($"   Gender         : {comboBox1.Text}");
                    writer.WriteLine($"   DOB            : {dateTimePicker1.Value.ToString("dd MMMM yyyy")}");
                    writer.WriteLine($"   Home Phone     : {CheckEmpty(textBox5)}"); //
                    writer.WriteLine($"   Mobile Phone   : {CheckEmpty(textBox6)}"); //
                    writer.WriteLine($"   Personal Email : {CheckEmpty(textBox10)}"); //
                    writer.WriteLine($"   Work Email     : {CheckEmpty(textBox11)}"); //
                    writer.WriteLine($"   Zip Code       : {CheckEmpty(textBox15)}"); //
                    writer.WriteLine($"   Emergency Phone: {CheckEmpty(textBox17)}"); //
                    writer.WriteLine("==================================================\n");
                }

                MessageBox.Show("บันทึกข้อมูลประวัติลงไฟล์ฐานข้อมูลเรียบร้อยแล้วครับ!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // 🔥 [อัปเดตใหม่ล่าสุด] สั่งให้ระบบเปิดไฟล์ Text (.txt) ขึ้นมาดูแบบอัตโนมัติทันที
                if (File.Exists(autoSaveFilePath))
                {
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = autoSaveFilePath,
                        UseShellExecute = true // บังคับให้เปิดด้วยโปรแกรมเริ่มต้นของระบบ (เช่น Notepad)
                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("เกิดข้อผิดพลาดในการบันทึกไฟล์:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string CheckEmpty(TextBox txt)
        {
            if (txt == null || string.IsNullOrWhiteSpace(txt.Text)) return "-";
            return txt.Text.Trim();
        }

        // =========================================================
        // 🔴 ปุ่ม "Clear All" ล้างข้อมูลทุกกล่องบนหน้าจอ
        // =========================================================
        private void button2_Click(object sender, EventArgs e)
        {
            ClearAllInputs(this);
            MessageBox.Show("ล้างข้อมูลบนหน้าจอทั้งหมดเรียบร้อยแล้วครับ", "Clear All", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ClearAllInputs(Control parent)
        {
            foreach (Control c in parent.Controls)
            {
                if (c is TextBox txt) txt.Clear();
                else if (c is ComboBox cb) cb.SelectedIndex = -1;
                else if (c is DateTimePicker dtp) dtp.Value = DateTime.Now;

                if (c.HasChildren) ClearAllInputs(c);
            }
        }

        // =========================================================
        // 🛠️ ส่วนป้องกัน Error จาก Event ค้างในไฟล์ดีไซเนอร์
        // =========================================================
        private void groupBox3_Enter(object sender, EventArgs e) { } //
        private void label2_Click(object sender, EventArgs e) { }
        private void groupBox2_Enter(object sender, EventArgs e) { }
        private void label12_Click(object sender, EventArgs e) { }
        private void groupBox1_Enter(object sender, EventArgs e) { }
        private void Form1_Load(object sender, EventArgs e) { }
    }
}